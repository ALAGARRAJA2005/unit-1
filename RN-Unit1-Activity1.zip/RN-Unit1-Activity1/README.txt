HOW TO RUN THIS TODO ACTIVITY
==============================

1. Open a terminal (or VS Code terminal) and go to the folder where you want
   your project to live, then create a new React app:

       npx create-react-app todo-activity

   This will create a folder called "todo-activity" with a working React
   project already set up (it takes a minute or two).

2. Go into that new folder:

       cd todo-activity

3. From the zip you downloaded, copy these 4 files into the "src" folder
   of the project you just created, REPLACING the existing files with the
   same names:

       src/App.js
       src/App.css
       src/index.js
       src/index.css

   (Keep everything else create-react-app generated, like package.json,
   public/, reportWebVitals.js, etc. Only the 4 files above need to be
   swapped in.)

4. Start the app:

       npm start

   This opens the app automatically at http://localhost:3000 in your
   browser.

5. Try it out:
   - Click "Add TODO" -> a popup box asks you to type text -> type
     something and press OK. It appears in the list.
   - Click the checkbox next to a todo to mark it checked/unchecked.
     Watch the "Unchecked todo count" update.
   - Click "delete" next to a todo to remove it.
   - Add a few todos, check some, delete one, so your screenshot shows
     all the features working.

6. Take a screenshot of the browser showing your todo list (with a few
   items added, at least one checked, and the counts visible).

7. Upload the screenshot using the GitHub link your instructor gave you.

WHAT WAS FILLED IN (App.js)
============================
Inside the Todo functional component, the blanks were completed as:

  checked={props.todo.checked}   -> reads the checked state from props
  onChange={props.onToggle}      -> calls the toggle handler passed via props
  onClick={props.onDelete}       -> calls the delete handler passed via props
  <span>{props.todo.text}</span> -> displays the todo's text

Everything else (the App class, state, addTodo, removeTodo, toggleTodo,
render) was left exactly as given in the starter code, since the
instructions said not to change it.
