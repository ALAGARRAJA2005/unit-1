import React from "react";
import './App.css';

let id = 0;

// ***** your code goes inside the function below *****
const Todo = (props) => (
  <li className={props.todo.checked ? "todo-item checked" : "todo-item"}>
    <input
      type="checkbox"
      checked={props.todo.checked}
      onChange={props.onToggle}
    />
    <span className="todo-text">{props.todo.text}</span>
    <button className="delete-btn" onClick={props.onDelete}>delete</button>
  </li>
);

class App extends React.Component {
  constructor() {
    super();
    this.state = {
      todos: []
    };
  }

  addTodo() {
    const text = prompt("TODO text please!");
    this.setState({
      todos: [...this.state.todos, { id: id++, text: text, checked: false }]
    });
  }

  removeTodo(id) {
    this.setState({
      todos: this.state.todos.filter((todo) => todo.id !== id)
    });
  }

  toggleTodo(id) {
    this.setState({
      todos: this.state.todos.map((todo) => {
        if (todo.id !== id) return todo;
        return {
          id: todo.id,
          text: todo.text,
          checked: !todo.checked
        };
      })
    });
  }

  render() {
    return (
      <div className="app-container">
        <h1 className="app-title">My Todo List</h1>
        <div className="stats">
          <span>Total: {this.state.todos.length}</span><br></br><br></br>
          <span>Unchecked: {this.state.todos.filter((todo) => !todo.checked).length}</span>
        </div><br></br><br></br>
        <button className="add-btn" onClick={() => this.addTodo()}>Add TODO</button>
        <ul className="todo-list">
          {this.state.todos.map((todo) => (
            <Todo
              onToggle={() => this.toggleTodo(todo.id)}
              onDelete={() => this.removeTodo(todo.id)}
              todo={todo}
              key={todo.id}
            />
          ))}
        </ul>
      </div>
    );
  }
}

export default App;