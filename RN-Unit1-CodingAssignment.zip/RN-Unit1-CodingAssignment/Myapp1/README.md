# RN Unit 1 - Coding Assignment: Todo App (Props and State)

Completed solution for the Todo application starter code.

## Folder structure
```
RN-Unit1-CodingAssignment/
├── App.js                # Completed Todo app - the Todo component blanks are filled in
├── package.json
└── screenshots/          # Put your output screenshots here
```

## What was filled in
Only the `Todo` functional component (the part marked "your code goes inside the function below")
was completed — everything else (the class `App`, `addTodo`, `removeTodo`, `toggleTodo`, `render()`,
and styles) is exactly as given, unchanged:

```js
const Todo = props => (
  <View style={[styles.todoContainer, styles.fill]}>
    <Switch
      value={props.todo.checked}
      onValueChange={props.onToggle}
    />
    <Button onPress={props.onDelete} title="delete" />
    <Text>{props.todo.text}</Text>
  </View>
)
```
- `style={[styles.todoContainer, styles.fill]}` — applies both required styles to the row.
- `value={props.todo.checked}` — the Switch reflects whether this todo is checked.
- `onValueChange={props.onToggle}` — toggling the switch calls the parent's toggle handler.
- `onPress={props.onDelete}` — the delete button calls the parent's delete handler.
- `{props.todo.text}` — displays this todo's text.

Note: the original starter code has `import {Constants} from 'expo'`, which is now deprecated in
current Expo SDKs and isn't actually used anywhere in the code, so it's kept only as a comment-safe
import and won't affect the app running. If your setup throws an error on that line specifically,
you can safely delete it — the instructions only restrict changing the *logic*, not obsolete imports.

## How to run on your Android device / emulator
```bash
cd RN-Unit1-CodingAssignment
npm install
npx expo start
```
- **Physical Android device**: install "Expo Go" from the Play Store, then scan the QR code shown in the terminal.
- **Android emulator**: press `a` in the terminal after `npx expo start` (needs Android Studio + an AVD set up).
- **Web browser** (quick preview): press `w` in the terminal, or run `npx expo start --web`.

If `npx expo start` fails with a missing command, first run:
```bash
npm install -g expo-cli
```

## What to test / screenshot
1. Tap "Add TODO" a few times — new todo rows should appear with a switch, delete button, and text.
2. Toggle a switch — "Unchecked todo count" at the top should update.
3. Tap "delete" on a row — that todo should disappear and "Todo count" should update.

Take a screenshot of the running app (ideally showing a few todos, one checked) and save it into
`screenshots/`, then paste it into the "output screen" spot in the assignment document before
uploading this project folder through your GitHub link.
