// Don't change the following code
import React from 'react';
import { View, Button, Text, ScrollView, StyleSheet, Switch } from 'react-native';

// don't change this line
let id = 0;

// Don't change the following code
const styles = StyleSheet.create({
  todoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  appContainer: {
    paddingTop: 50, //Constants.statusBarHeight,
  },
  fill: {
    flex: 1,
  },
  deleteBtnWrapper: {
    width: 70,
  }
})

// ***** your code goes inside the function below *****
const Todo = props => (
  // apply todoContainer and fill styles
  <View style={[styles.todoContainer, styles.fill]}>
    {/* call checked of todo using props */}
    <Switch
      value={props.todo.checked}
      // call onToggle using props
      onValueChange={props.onToggle}
    />
    {/* call onDelete using props */}
    <View style={styles.deleteBtnWrapper}>
      <Button onPress={props.onDelete} title="delete" color="red" />
    </View>
    {/* set text of todo using props */}
    <Text>{props.todo.text}</Text>
  </View>
)

// Don't change the following class code
// create a class component App that extends React Component
export default class App extends React.Component {
  constructor() {
    super()
    this.state = {
      todos: [],
    }
  }

  // Don't change the following addTodo() code
  // This function create a method that get input from user
  // also this fucntion creates an array with todo with id, text
  // and checkbox
  addTodo() {
    id++
    const text = `TODO number ${id}`
    this.setState({
      todos: [
        ...this.state.todos,
        { id: id, text: text, checked: false },
      ],
    })
  }

  // Don't change the following function code
  // This fucntion remove selected todo from todo list
  removeTodo(id) {
    this.setState({
      todos: this.state.todos.filter(todo => todo.id !== id)
    })
  }

  // Don't change the following function code
  // This fucntion adds a toggle fucntionality to checkboxes in the
  // todo list and update list after each toggle mode (check/ uncheck)
  toggleTodo(id) {
    this.setState({
      todos: this.state.todos.map(todo => {
        if (todo.id !== id) return todo
        return {
          id: todo.id,
          text: todo.text,
          checked: !todo.checked,
        }
      })
    })
  }

  // Don't change the following render() code
  // react's render method that renders
  // Todo' checked count,unchecked count, Add todo button,
  // delete button,check box for each todo, todo text
  render() {
    return (
      <View style={[styles.appContainer, styles.fill]}>
        <Text>Todo count: {this.state.todos.length}</Text>
        <Text>Unchecked todo count: {this.state.todos.filter(todo => !todo.checked).length}</Text>
        <Button onPress={() => this.addTodo()} title="Add TODO" />
        <ScrollView style={styles.fill}>
          {this.state.todos.map(todo => (
            <Todo
              onToggle={() => this.toggleTodo(todo.id)}
              onDelete={() => this.removeTodo(todo.id)}
              todo={todo}
            />
          ))}
        </ScrollView>
      </View>
    )
  }
}