import React from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';

// Switch the import below to preview each exercise's class component output
// import Exercise1_Cat from './components/Exercise1_Cat';
// import Exercise2_FullName from './components/Exercise2_FullName';
// import Exercise3_TextInput from './components/Exercise3_TextInput';

import Exercise4_Cafe from './components/Exercise4_Cafe';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Exercise4_Cafe />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 16,
  },
});
