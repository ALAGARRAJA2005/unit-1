# RN Unit 1 - Coding Activity 2: JSX and Custom Components

Functional-to-class-component conversions for all four exercises in the activity sheet.

## Folder structure
```
RN-Unit1-Activity2/
├── App.js                          # Entry point - swap the import to preview an exercise
├── package.json
├── components/
│   ├── Exercise1_Cat.js            # JSX: simple greeting
│   ├── Exercise2_FullName.js       # JSX: greeting with a helper function
│   ├── Exercise3_TextInput.js      # Custom component: Text + TextInput
│   └── Exercise4_Cafe.js           # Custom component: Cafe rendering 3 Cat components
└── screenshots/                    # Put your output screenshots here (see below)
```

Each file in `components/` contains:
1. The **original functional component** from the activity sheet (commented "Original Functional Component"), kept for reference.
2. **Your solution** — the same component rewritten as a class component (`class X extends React.Component { render() {...} }`), which is what's actually exported and used.

## How to run on your Android device / simulator
1. Install Node.js (LTS) and the Expo CLI if you don't have them:
   ```
   npm install -g expo-cli
   ```
2. Unzip this project, then from inside the folder install dependencies:
   ```
   cd RN-Unit1-Activity2
   npm install
   ```
3. Start the Metro bundler:
   ```
   npx expo start
   ```
4. Run it:
   - **Physical Android device**: install the "Expo Go" app from the Play Store, then scan the QR code shown in the terminal/browser.
   - **Android emulator**: press `a` in the terminal after `expo start` (requires Android Studio + an AVD configured).

## Previewing each exercise
`App.js` renders one exercise at a time. To view a different exercise, open `App.js`, comment out the current import/usage and uncomment the one you want, e.g.:
```js
import Exercise2_FullName from './components/Exercise2_FullName';
...
<Exercise2_FullName />
```
Save the file — Expo will hot-reload automatically.

## Adding your output screenshots
Take a screenshot of each exercise running (in the emulator or on your device), save them into the `screenshots/` folder, named to match, e.g.:
```
screenshots/
├── exercise1_output.png
├── exercise2_output.png
├── exercise3_output.png
└── exercise4_output.png
```
Then paste each screenshot under the matching "Output Screen" section in the original activity PDF/Word doc before you upload it, along with this project folder, through the GitHub link your instructor provided.
