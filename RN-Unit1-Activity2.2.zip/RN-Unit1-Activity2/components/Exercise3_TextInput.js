import React from 'react';
import { Text, TextInput, View } from 'react-native';

// ---------- Original Functional Component ----------
const CatFunctional = () => {
  return (
    <View>
      <Text>Hello, I am...</Text>
      <TextInput
        style={{
          height: 40,
          borderColor: 'gray',
          borderWidth: 1
        }}
        defaultValue="Name me!"
      />
    </View>
  );
}

// ---------- Your Solution: Class Component ----------
class Cat extends React.Component {
  render() {
    return (
      <View>
        <Text>Hello, I am...</Text>
        <TextInput
          style={{
            height: 40,
            borderColor: 'gray',
            borderWidth: 1
          }}
          defaultValue="Name me!"
        />
      </View>
    );
  }
}

export default Cat;
