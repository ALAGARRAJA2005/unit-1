# RN Unit 1 - Coding Activity 3: Props and State

Solutions for all three exercises in the activity sheet.

## Folder structure
```
RN-Unit1-Activity3/
├── App.js                             # Entry point - swap the import to preview an exercise
├── package.json
├── components/
│   ├── Exercise1_MultipleProps.js     # Cafe passing different "name" prop to 3 Cat components
│   ├── Exercise2_ImageProps.js        # CatApp displaying a remote Image via props
│   └── Exercise3_StateAndStyles.js    # Cat/Cafe class components using state + StyleSheet.create
└── screenshots/                       # Put your output screenshots here
```

Each file contains the given code plus "Your Solution" comments marking what was added/changed.
Exercise 3 adds `StyleSheet.create` (container, paragraph, btnColor styles) and applies them to the
View, Text and Button inside the Cat class component, on top of the given state logic.

## How to run on your Android device / simulator
```bash
cd RN-Unit1-Activity3
npm install
npx expo start
```
- **Physical Android device**: install "Expo Go" from the Play Store, then scan the QR code shown in the terminal.
- **Android emulator**: press `a` in the terminal after `npx expo start` (needs Android Studio + an AVD set up).

If `npx expo start` fails with a missing command, first run:
```bash
npm install -g expo-cli
```

## Previewing each exercise
Open `App.js`, comment out the current import/usage and uncomment the one you want to view, e.g.:
```js
import Exercise3_StateAndStyles from './components/Exercise3_StateAndStyles';
...
<Exercise3_StateAndStyles />
```
Save the file — Expo hot-reloads automatically.

## Adding your output screenshots
Save each exercise's screenshot into `screenshots/`, e.g. `exercise1_output.png`, `exercise2_output.png`,
`exercise3_output.png`, then paste them into the matching "Add your Output Screen" spot in the
activity document before uploading the project folder through your GitHub link.
