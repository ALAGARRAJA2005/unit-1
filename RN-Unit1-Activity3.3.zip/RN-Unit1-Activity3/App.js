import React from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';

// Switch the import below to preview each exercise's output
// import Exercise1_MultipleProps from './components/Exercise1_MultipleProps';
//  import Exercise2_ImageProps from './components/Exercise2_ImageProps';
 import Exercise3_StateAndStyles from './components/Exercise3_StateAndStyles';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Exercise3_StateAndStyles />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 16,
  },
});
