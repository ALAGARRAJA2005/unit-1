import React from 'react';
import { Text, View } from 'react-native';

// ---------- Given Code ----------
const Cat = (props) => {
  return (
    <View>
      <Text>Hello, I am {props.name}!</Text>
    </View>
  );
}

// ---------- Your Solution ----------
// Cafe renders multiple Cat components, passing a different
// "name" prop to each. Each Cat reads props.name and re-renders
// its own Text with the value it received.
const Cafe = () => {
  return (
    <View>
      <Cat name="Maru" />
      <Cat name="Jellylorum" />
      <Cat name="Spot" />
    </View>
  );
}

export default Cafe;
