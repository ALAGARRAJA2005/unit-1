import React, { Component } from "react";
import { Button, Text, View, StyleSheet } from "react-native";

// ---------- Your Solution ----------
// Styles created with StyleSheet.create and applied to the
// View, Text and Button custom components below.
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 50, //Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#34495e',
  },
  btnColor: {
    color: '#f194ff',
  }
});

class Cat extends Component {
  state = { isMobile: true };

  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.paragraph}>
          I am {this.props.name}, and I am
          {this.state.isMobile ? " New " : " 2021 Model"}!
        </Text>
        <Button
          color={styles.btnColor.color}
          onPress={() => {
            this.setState({ isMobile: false });
          }}
          disabled={!this.state.isMobile}
          title={
            this.state.isMobile ? "Click Here to know" : "Thank you!"
          }
        />
      </View>
    );
  }
}

class Cafe extends Component {
  render() {
    return (
      <View style={styles.container}>
        <Cat name="Android Mobile" />
        <Cat name="Apple Mobile" />
      </View>
    );
  }
}

export default Cafe;
