import React from 'react';
import { Text, View, Image } from 'react-native';

// ---------- Given Code / Your Solution ----------
// The Image component takes a "source" prop (an object with a uri
// for remote images) and "style" prop to control its size.
const CatApp = () => {
  return (
    <View>
      <Image
        source={{ uri: "https://reactnative.dev/docs/assets/p_cat1.png" }}
        style={{ width: 200, height: 200 }}
      />
      <Text>Hello, I am your cat!</Text>
    </View>
  );
}

export default CatApp;
